## to bootstrap:

1. get ollama and chromadb dependencies sorted

2. in terminal run:  ollama pull snowflake-arctic-embed:latest  (or whatever docs say)

2a (optional). In terminal run: ollama run snowflake-arctic-embed to confirm it worked

3. run 'python embed.py'

If that works without error, then run...

4. run 'python inference.py '..your custom description...'

Examples of fun ones:
'evil genius'
'STEM professional'